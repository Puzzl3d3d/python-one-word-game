
for folder in ["client", "server"]:
    with open(f"src/{folder}/args.py", "r") as file:
        args_data = file.read()
        args_data = args_data[:args_data.index("if __name__ == \"__main__\"")] # Remove stuff than runs when the module is directly ran
    with open(f"src/{folder}/simplesocket.py", "r") as file:
        ss_data = file.read()
        ss_data = ss_data[:ss_data.index("if __name__ == \"__main__\"")] # Remove stuff than runs when the module is directly ran
        ss_data = ss_data.replace("from args import args", "") # Remove unnecessary and unfound imports
    with open(f"src/{folder}/main.py", "r") as file:
        main_data = file.read().replace("from args import args", "").replace("from simplesocket import SimpleSocket" ,"") # Remove unnecessary and unfound imports
    with open(f"dist/{folder}.py", "w") as file:
        file.write("\n\n\n# -- NEW FILE HEADER --\n\n\n".join([args_data, ss_data, main_data]))